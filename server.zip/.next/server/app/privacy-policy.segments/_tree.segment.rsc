:HL["/_next/static/css/f3b27e57e18a56e1.css","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":"privacy-policy","h":64,"c":"$Q3"}]]
1:[["children",{"s":"(website)","h":32,"c":"$Q2"}]]
0:{"b":"GXrHxksiZ98y5AfsYYSrD","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
