1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
4:"static/chunks/6609-278385ce0efea68b.js"
5:"static/chunks/app/layout-130eaa3265a2d51a.js"
6:I[6609,["6609","$4","7177","$5"],"Toaster"]
8:"ClientSegmentRoot"
9:I[8616,[],"$8"]
a:"static/chunks/8500-107859ed31978aa3.js"
b:"static/chunks/app/admin/layout-176b7b44e174bbad.js"
c:I[4701,["8500","$a","7581","$b"],"default"]
11:"static/chunks/app/admin/pricing/page-c87bf354553b9e5d.js"
12:I[4755,["8500","$a","247","$11"],"default"]
13:I[484,[],"OutletBoundary"]
14:"$Sreact.suspense"
16:"ViewportBoundary"
17:I[484,[],"$16"]
19:"MetadataBoundary"
1a:I[484,[],"$19"]
1c:I[7123,[],"default",1]
:HL["/_next/static/css/f3b27e57e18a56e1.css","style"]
f:X
10:[["children",{"s":"__PAGE__","h":512,"d":{"r":["$","$1","c",{"children":[["$","$L12",null,{"initialPlans":[{"id":"basic","slug":"basic","name":"Basic Plan","price":299,"currency":"USD","billingPeriod":"month","billingLabel":"/mo","note":"$$299.00 Plus Per Deletion Fees","buttonLabel":"Choose Basic Plan","href":"/appointment","description":"Essential credit repair services.","featured":false,"features":["Personal Info $10.","Inquiries $50.","Collections $75.","Public Records $150.","Debt Settlement: 15% (On Saved Amounts).","24/7 Online Access to Your Account.","Add Your Spouse for $150 Special!","Unlimited Bureau Disputes.","Unlimited Creditor Disputes.","Unlimited Collection Disputes."]},{"id":"gold","slug":"gold","name":"Gold Plan","price":450,"currency":"USD","billingPeriod":"month","billingLabel":"/mo","note":"$$450.00 Plus Per Deletion Fees","buttonLabel":"Choose Gold Plan","href":"/appointment","description":"Additional features and account support.","featured":true,"features":["Free Setup.","FREE 24/7 Access.","Add Your Spouse for $229 Special.","Includes All \"BASIC\" Plan Features.","File Handled Directly by Our Owner."]}]}],null,["$","$L13",null,{"children":["$","$14",null,{"name":"Next.MetadataOutlet","children":"$@15"}]}]]}],"p":false,"v":null}}]]
e:[["children",{"s":"pricing","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$f"},"c":"$Q10"}]]
7:[["children",{"s":"admin","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L9",null,{"Component":"$c","slots":{"children":["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]},"serverProvidedParams":{"params":{},"promises":["$@d"]}}]]}],"p":false,"v":null},"c":"$Qe"}]]
0:{"P":null,"c":["","admin","pricing"],"q":"","i":false,"t":{"t":{"s":"","h":528,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/f3b27e57e18a56e1.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"__variable_d8ebd1 __variable_532bb9","children":["$","body",null,{"className":"min-h-screen flex flex-col font-sans antialiased","children":[["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}],["$","$L6",null,{"position":"top-right","richColors":true,"closeButton":true,"duration":4000}]]}]}]]}],"p":false,"v":null},"c":"$Q7"},"h":{"r":["$","$1","h",{"children":[null,["$","$L17",null,{"children":"$L18"}],["$","$L1a",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$14",null,{"name":"Next.Metadata","children":"$L1b"}]}],null]}],null]}],"p":false,"v":null}},"m":"$undefined","G":["$1c",[]],"S":true,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"GXrHxksiZ98y5AfsYYSrD"}
f:C
d:"$7:0:1:d:r:props:children:1:props:serverProvidedParams:params"
18:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
1d:I[6869,[],"IconMark"]
15:null
1b:[["$","title","0",{"children":"Pricing Management | Ultra Credit Solutions | Ultra Credit Solutions USA"}],["$","meta","1",{"name":"description","content":"Manage existing pricing plans."}],["$","link","2",{"rel":"shortcut icon","href":"/favicon.png"}],["$","link","3",{"rel":"icon","href":"/favicon.png","type":"image/png"}],["$","link","4",{"rel":"icon","href":"/favicon.ico","type":"image/x-icon"}],["$","link","5",{"rel":"apple-touch-icon","href":"/favicon.png"}],["$","$L1d","6",{}]]
