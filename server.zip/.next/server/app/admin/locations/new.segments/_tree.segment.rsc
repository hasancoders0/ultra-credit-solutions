:HL["/_next/static/css/f3b27e57e18a56e1.css","style"]
4:[["children",{"s":"__PAGE__","h":160}]]
3:[["children",{"s":"new","h":96,"c":"$Q4"}]]
2:[["children",{"s":"locations","h":96,"c":"$Q3"}]]
1:[["children",{"s":"admin","h":96,"c":"$Q2"}]]
0:{"b":"GXrHxksiZ98y5AfsYYSrD","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
