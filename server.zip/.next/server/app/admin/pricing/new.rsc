1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
4:"static/chunks/6609-278385ce0efea68b.js"
5:"static/chunks/app/layout-130eaa3265a2d51a.js"
6:I[6609,["6609","$4","7177","$5"],"Toaster"]
8:"ClientSegmentRoot"
9:I[8616,[],"$8"]
a:"static/chunks/8500-107859ed31978aa3.js"
b:"static/chunks/app/admin/layout-176b7b44e174bbad.js"
c:I[4701,["8500","$a","7581","$b"],"default"]
12:"static/chunks/2958-549952eff9f0dbdb.js"
13:"static/chunks/app/admin/pricing/new/page-7f0ed2e0f69c4714.js"
14:I[1763,["8500","$a","2958","$12","4362","$13"],"default"]
15:I[484,[],"OutletBoundary"]
16:"$Sreact.suspense"
18:"ViewportBoundary"
19:I[484,[],"$18"]
1b:"MetadataBoundary"
1c:I[484,[],"$1b"]
1e:I[7123,[],"default",1]
:HL["/_next/static/css/f3b27e57e18a56e1.css","style"]
f:X
11:[["children",{"s":"__PAGE__","h":512,"d":{"r":["$","$1","c",{"children":[["$","$L14",null,{}],null,["$","$L15",null,{"children":["$","$16",null,{"name":"Next.MetadataOutlet","children":"$@17"}]}]]}],"p":false,"v":null}}]]
10:[["children",{"s":"new","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$f"},"c":"$Q11"}]]
e:[["children",{"s":"pricing","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$f"},"c":"$Q10"}]]
7:[["children",{"s":"admin","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L9",null,{"Component":"$c","slots":{"children":["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]},"serverProvidedParams":{"params":{},"promises":["$@d"]}}]]}],"p":false,"v":null},"c":"$Qe"}]]
0:{"P":null,"c":["","admin","pricing","new"],"q":"","i":false,"t":{"t":{"s":"","h":528,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/f3b27e57e18a56e1.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"__variable_d8ebd1 __variable_532bb9","children":["$","body",null,{"className":"min-h-screen flex flex-col font-sans antialiased","children":[["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}],["$","$L6",null,{"position":"top-right","richColors":true,"closeButton":true,"duration":4000}]]}]}]]}],"p":false,"v":null},"c":"$Q7"},"h":{"r":["$","$1","h",{"children":[null,["$","$L19",null,{"children":"$L1a"}],["$","$L1c",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$16",null,{"name":"Next.Metadata","children":"$L1d"}]}],null]}],null]}],"p":false,"v":null}},"m":"$undefined","G":["$1e",[]],"S":true,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"GXrHxksiZ98y5AfsYYSrD"}
f:C
d:"$7:0:1:d:r:props:children:1:props:serverProvidedParams:params"
1a:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
1f:I[6869,[],"IconMark"]
17:null
1d:[["$","title","0",{"children":"Add Pricing Plan | Ultra Credit Solutions | Ultra Credit Solutions USA"}],["$","meta","1",{"name":"description","content":"Learn about Ultra Credit Solutions USA and explore our services, educational resources, and available support options."}],["$","link","2",{"rel":"shortcut icon","href":"/favicon.png"}],["$","link","3",{"rel":"icon","href":"/favicon.png","type":"image/png"}],["$","link","4",{"rel":"icon","href":"/favicon.ico","type":"image/x-icon"}],["$","link","5",{"rel":"apple-touch-icon","href":"/favicon.png"}],["$","$L1f","6",{}]]
