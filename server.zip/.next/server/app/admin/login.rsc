1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
4:"static/chunks/6609-278385ce0efea68b.js"
5:"static/chunks/app/layout-130eaa3265a2d51a.js"
6:I[6609,["6609","$4","7177","$5"],"Toaster"]
8:"ClientSegmentRoot"
9:I[8616,[],"$8"]
a:"static/chunks/8500-107859ed31978aa3.js"
b:"static/chunks/app/admin/layout-176b7b44e174bbad.js"
c:I[4701,["8500","$a","7581","$b"],"default"]
11:I[1304,[],"ClientPageRoot"]
12:"static/chunks/app/admin/login/page-03c367b86c745283.js"
13:I[9047,["8500","$a","2116","$12"],"default"]
16:I[484,[],"OutletBoundary"]
17:"$Sreact.suspense"
19:"ViewportBoundary"
1a:I[484,[],"$19"]
1c:"MetadataBoundary"
1d:I[484,[],"$1c"]
1f:I[7123,[],"default",1]
:HL["/_next/static/css/f3b27e57e18a56e1.css","style"]
f:X
10:[["children",{"s":"__PAGE__","h":512,"d":{"r":["$","$1","c",{"children":[["$","$L11",null,{"Component":"$13","serverProvidedParams":{"searchParams":{},"params":"$7:0:1:d:r:props:children:1:props:serverProvidedParams:params","promises":["$@14","$@15"]}}],null,["$","$L16",null,{"children":["$","$17",null,{"name":"Next.MetadataOutlet","children":"$@18"}]}]]}],"p":false,"v":null}}]]
e:[["children",{"s":"login","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$f"},"c":"$Q10"}]]
7:[["children",{"s":"admin","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L9",null,{"Component":"$c","slots":{"children":["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]},"serverProvidedParams":{"params":{},"promises":["$@d"]}}]]}],"p":false,"v":null},"c":"$Qe"}]]
0:{"P":null,"c":["","admin","login"],"q":"","i":false,"t":{"t":{"s":"","h":528,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/f3b27e57e18a56e1.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"__variable_d8ebd1 __variable_532bb9","children":["$","body",null,{"className":"min-h-screen flex flex-col font-sans antialiased","children":[["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}],["$","$L6",null,{"position":"top-right","richColors":true,"closeButton":true,"duration":4000}]]}]}]]}],"p":false,"v":null},"c":"$Q7"},"h":{"r":["$","$1","h",{"children":[null,["$","$L1a",null,{"children":"$L1b"}],["$","$L1d",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$17",null,{"name":"Next.Metadata","children":"$L1e"}]}],null]}],null]}],"p":false,"v":null}},"m":"$undefined","G":["$1f",[]],"S":true,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"GXrHxksiZ98y5AfsYYSrD"}
f:C
d:"$7:0:1:d:r:props:children:1:props:serverProvidedParams:params"
14:{}
15:"$7:0:1:d:r:props:children:1:props:serverProvidedParams:params"
1b:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
20:I[6869,[],"IconMark"]
18:null
1e:[["$","title","0",{"children":"Ultra Credit Solutions USA"}],["$","meta","1",{"name":"description","content":"Learn about Ultra Credit Solutions USA and explore our services, educational resources, and available support options."}],["$","link","2",{"rel":"shortcut icon","href":"/favicon.png"}],["$","link","3",{"rel":"icon","href":"/favicon.png","type":"image/png"}],["$","link","4",{"rel":"icon","href":"/favicon.ico","type":"image/x-icon"}],["$","link","5",{"rel":"apple-touch-icon","href":"/favicon.png"}],["$","$L20","6",{}]]
